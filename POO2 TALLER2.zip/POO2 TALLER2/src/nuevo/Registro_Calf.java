package nuevo;

public abstract class Registro_Calf  {
    protected Integer ID;
    protected String Nombre;

    public Registro_Calf(Integer ID, String Nombre){

    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public abstract void pedir()throws Exception;

}
