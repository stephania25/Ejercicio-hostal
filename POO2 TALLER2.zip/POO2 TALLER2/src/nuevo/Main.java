package nuevo;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        int opc;


        Materias mat = null;
        Estudiantes est = null;

        Estudiantes e1 = new Estudiantes(1024627, "Calculo", 2,mat);
        Estudiantes e2 = new Estudiantes(1034567, "Programacion", 4, mat);


        Materias m1 = new Materias(157956, "julian Rodriguez", 4.50f, est);
        Materias m2 = new Materias(124528, "Carlos Cardozo", 5.00f, est);

        System.out.println("MENU");
        System.out.println("Elija una opcion que desea averiguar notas.");
        System.out.println("1. Materias");
        System.out.println("2. Estudiante");

        opc = scan.nextInt();
        switch (opc) {
            case 1:

                System.out.println(" Que materia desea averiguar?");
                System.out.println("1. Calculo");
                System.out.println("2. Programación");

                opc = scan.nextInt();

                switch (opc) {

                    case 1:

                        System.out.println(" Que estudiante desea averiguar?");
                        System.out.println("1. Julian Rodriguez");
                        System.out.println("2. Carlos Cardozo");

                        opc = scan.nextInt();

                        switch (opc) {

                            case 1:

                                m1.setEst(e1);

                                break;
                            case 2:

                                m1.setEst(e2);
                                break;

                            default:
                                System.out.println("No existe esa opcion");
                                break;

                        }
                        try {
                            m1.pedir();
                        } catch (Exception ex) {
                            System.out.println("Acción invalida");
                            System.out.println(ex.getMessage());

                        } finally {
                            System.out.println("Fin de la operacion");

                        }
                        break;

                    case 2:

                        System.out.println(" Que estudiante desea averiguar?");
                        System.out.println("1. Julian Rodriguez");
                        System.out.println("2. Carlos Cardozo");

                        opc = scan.nextInt();

                        switch (opc) {
                            case 1:
                                m2.setEst(e1);
                                break;

                            case 2:
                                m2.setEst(e2);
                                break;

                            default:
                                System.out.println("No existe esa opcion");
                                break;

                        }

                        try {
                            e2.pedir();
                        } catch (Excepcion ex) {

                            System.out.println("Operacion invalida");
                            System.out.println(ex.getMessage());

                        } catch (NullPointerException e) {
                            System.out.println("Excepcion por un valor nulo");
                        } finally {
                            System.out.println("Fin de la operacion");

                        }
                        break;
                    default:
                        System.out.println("");
                }
                break;
            case 2:
                System.out.println("Que estudiante desea averiguar?");
                System.out.println("1. Julian Rodriguez");
                System.out.println("2. Carlos Cardozo");

                opc = scan.nextInt();

                switch (opc) {
                    case 1:

                        System.out.println(" Que materia desea averiguar?");
                        System.out.println("1. Calculo");
                        System.out.println("2. Programación");
                        opc = scan.nextInt();

                        switch (opc) {
                            case 1:
                                e1.setMat(m1);
                                break;

                            case 2:
                                e2.setMat(m2);
                                break;
                            default:
                                System.out.println("No existe esa opcion");
                                break;
                        }

                        try {
                            e1.pedir();
                        } catch (Excepcion ex) {
                            System.out.println("Operacion invalida");
                            System.out.println(ex.getMessage());

                        } catch (NullPointerException ex) {
                            System.out.println("Excepcion por un valor nulo");
                        } finally {
                            System.out.println("Fin de la operacion");

                        }
                        break;

                    case 2:
                        System.out.println(" Que materia desea averiguar?");
                        System.out.println("1. Calculo");
                        System.out.println("2. Programación");

                        opc = scan.nextInt();

                        switch (opc) {

                            case 1:
                                e2.setMat(m1);

                                break;
                            case 2:

                                e2.setMat(m2);
                                break;

                            default:
                                System.out.println("No existe esa opcion");
                                break;

                            }
                        try {
                            e2.pedir();
                        } catch (Excepcion ex) {

                            System.out.println("Operacion invalida");
                            System.out.println(ex.getMessage());

                        } catch (NullPointerException ex) {
                            System.out.println("Excepcion por un valor nulo");
                        } finally {
                            System.out.println("Fin de la operacion");

                        }
                        break;

                    default:
                        System.out.println("");

                }
                break;

            default:
                System.out.println("Opcion invalida.");

            }

    }
}