package nuevo;

public class Estudiantes extends Registro_Calf {

    private int curso;
    private Materias mat;

    public Estudiantes(Integer ID, String Nombre, int curso, Materias mat) {
        super(ID, Nombre);
        this.curso = curso;
        this.mat = mat;
    }

    public int getCurso() {
        return curso;
    }

    public void setCurso(int curso) {
        this.curso = curso;
    }

    public Materias getMat() {
        return mat;
    }

    public void setMat(Materias mat) {
        this.mat = mat;
    }


    @Override
    public void pedir() throws Exception {
        if (getMat().getNota() < 5.00f) {

            System.out.println("Estudiante: " + getNombre() + " / id: " + getID() + "/ semestre: " + getCurso());
            System.out.println("Materia: " + getNombre() + " / id: " + getID());
            System.out.println("Nota: " + getMat().getNota());

        } else {

            throw new Excepcion("La nota ingresada es invalida");

        }

    }
}

