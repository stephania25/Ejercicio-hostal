package nuevo;

public class Excepcion extends Exception{
    private String mensaje;

    public Excepcion(String mensaje) {
        this.mensaje = mensaje;
    }

    @Override
    public String getMessage() {
        System.out.println("Error");
        return this.getMessage();
    }
}
