package nuevo;

public class Materias extends Registro_Calf {
  private float nota;
  private Estudiantes est;

  public Materias(Integer ID, String Nombre, float nota, Estudiantes est) {
    super(ID, Nombre);
    this.nota = nota;
    this.est = est;
  }

  public float getNota() {
    return nota;
  }

  public void setNota(float nota) {
    this.nota = nota;
  }

  public Estudiantes getEst() {
    return est;
  }

  public void setEst(Estudiantes est) {
    this.est = est;
  }
  @Override

  public void pedir() throws Exception {
    if (nota < 5.00f) {
          nota = nota;
          System.out.println("Nota: " + nota);

          System.out.println("Materia: " + Nombre+ " / id: " + ID );

      System.out.println("Estudiante: " + est.getNombre() + " / id: " + est.getID() + " / semestre: " + getEst().getCurso());
    } else {

      throw new Excepcion("La nota ingresada es invalida");

    }

  }

}

